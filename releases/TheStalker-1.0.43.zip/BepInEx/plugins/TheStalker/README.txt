THE STALKER 1.0.43 - by Blackout Addons
=====================================

A new boss for Labs - and, at night, every other map. He only carries a knife, wears a Glorious E mask, black clothes and a black chest rig full of stims,
and makes no sound when he moves. He stalks you from behind in the dark, muttering in the Cultists' voice,
and strikes when you're not looking. Spot him far away and he runs. Shine a flashlight on him and he screams and runs.
Find him or shoot him up close (within 8 m) and he doesn't run - he comes for you.
Drive him off 3 times within a minute and he slips far back and shadows you from 30-40 m for a while before he comes close again.
But once he's charging and within 8 m, he commits: looking, light or bullets won't turn him back.
That's your moment to shoot him. Destroying a leg is the only thing that stops the charge.
He opens shut doors on his way, quietly (setting "Opens doors"). A door you closed behind you may not stay closed.

He also carries a holstered Makarov he never draws (the game won't switch on a bot
without a gun - the zombies carry one for the same reason).

His knife: 3 heavy bleeds, poison, and (50% chance) a few seconds of white-out like a flashbang.
You hear the stab, your own gasp, then ringing and your heartbeat fading with the white-out.
- Backstab: a charge you never saw coming hits twice as hard (the same again to your chest).
- While you're whited out he stays on you for a second cut (setting "Cuts per attack", 1-3), then he's gone.
- Smells blood: bleeding or below half health, he's back in 10-20 s instead of 30-60 s.
He can be killed, but it takes work: 1120 HP, head 120 and chest 350 so a few hits won't drop him, and he runs as soon as he's hurt. He sometimes carries a marked key (in his chest rig).

THE LIGHTS DIE AROUND HIM (needs Blackout Addons 1.27.5+)
Every light right next to him goes out (main lights, emergency lamps, beacons), and a bit further away they
flicker and die as he passes (Blackout Addons 1.27.6+ for all lights; 1.27.5 only the emergency lamps).
Your own light flickers too when he's close, and stutters the whole time you point it at him (within 30 m, any light, a pistol light too).
Setting: "Your light stutters on him".
A corridor going dark lamp by lamp means he's coming. Setting: "Lights die around him".

HIS LAUGHS
His laughs were recorded for this mod (lowered and darkened, with a corridor echo): 2 while he stalks you, 2 quiet ones up close.

HIS STIMS (he's a junkie)
He carries 6 stims, picked at random each raid from nine (never two of the same). The ones he didn't use are loot.
Healing - when he's badly hurt and out of your sight he stops and injects one:
  Zagustin when he's bleeding, eTG-c / Propital / Perfotoran when his health is low, Trimadol when a leg is gone.
Highs - on purpose. Right before a charge he may stop and shoot up (you hear the injector, then he laughs):
  - Obdolbos 2: BERSERK for 30 s. Your light doesn't scare him, looking at him or shooting him makes him charge,
    and he's faster. Then he CRASHES for 10 s: slow, stumbling, no charging - that's your chance to kill him.
  - Adrenaline: he lunges - the first 4 s of the charge are extra fast.
  - PNB: deeper cuts for 90 s - half the damage again and one more heavy bleed per cut.
  - SJ6: after you drive him off, he takes it while hiding - his bolts are faster for 2 minutes.
While he's high he laughs twice as often.
Any stim brings a destroyed leg back and gives him a few seconds of extra speed.
Settings: "Stims he uses" (client, how many per raid) and "stims" in config.jsonc (server, how many he carries).

WHEN HE COMES
- With Blackout Addons: in blackout raids, when the generator control burns out,
  or after 10 minutes with the lights out.
  Full power (needs Blackout Addons 1.27.10+): bright spots buy you time - he waits for you to step into the dark,
  but after 20 s in the light he comes anyway (35 s at half power or in the dark's few lit spots),
  and the lights around him die as he comes. In the lit facility your flashlight doesn't scare him, spot him within
  15 m and he charges, and drive him off 3 times in a minute and he gets enraged: a 20 s charge that ignores light,
  looks and bullets (only a destroyed leg stops it). He also comes back sooner between charges. A minute or two after the power is back he may sneak to the generator
  switch and shut it down (up to twice a raid). Stand near the switch and he waits. Setting: "Cuts the power".
  If you carry Admin's key, he marks you: closer, more often.
  When Killa breaks in, the Stalker stays - and Killa and Tagilla will fight him (setting "Slips away when Killa breaks in").
- Without Blackout Addons: 12 minutes into a Labs raid.
- Other maps (Customs, Factory, Interchange, Lighthouse, Reserve, Shoreline, Streets, Woods, Ground Zero):
  only in night raids (21:00-05:00 game time). The Labyrinth: any time, it's underground.
  He wakes at a random time 8-20 minutes in. No PA warning there - just a laugh somewhere in the dark.
  With Blackout Addons the lights around him die there too (street lamps, building lights).
  Setting: "Other maps (night raids)".
- 35% chance per raid (setting), the same on every map.

REQUIRES
- SPT 4.1.x
- MoreBotsAPI 2.1+ and BigBrain
- Optional: Blackout Addons 1.27.0+ (Blackout by Vultify) for the blackout link

INSTALL
Extract into your game folder (the one with EscapeFromTarkov.exe):
  BepInEx/patchers/TheStalkerPrepatch.dll
  BepInEx/plugins/TheStalker/
  SPT_Runtime/user/mods/TheStalker/

UPDATING
Delete the old BepInEx/plugins/TheStalker folder first (or uninstall and reinstall in your mod manager):
sounds removed in a new version stay behind otherwise, and still play.

SETTINGS
F12 > The Stalker: chance, wake time, bleeds, poison, blind time, sprint speed,
flashlight, commit distance, stims he can use, volume, PA language. Testing: Ctrl+F6 wakes him right away in Labs.
Server: SPT_Runtime/user/mods/TheStalker/config.jsonc (marked key chance, health %, how many stims he carries).

Not affiliated with Battlestate Games or the SPT team.
